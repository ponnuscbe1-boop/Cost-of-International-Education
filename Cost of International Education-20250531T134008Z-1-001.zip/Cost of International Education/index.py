import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the large dataset
df = pd.read_csv("D:\Sarath\Minnsudar\Internship Projects\Cost of International Education\Dataset.csv")

# ----- Basic Info -----
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print("Missing values:\n", df.isnull().sum())

# ----- Data Cleaning -----
df.dropna(inplace=True)  # Optional: Remove missing rows if any

# ----- Normalized Costs -----
# Adjusting cost columns using exchange rate
for col in ["Tuition_USD", "Rent_USD", "Visa_Fee_USD", "Insurance_USD"]:
    df[f"{col}_Adj"] = df[col] / df["Exchange_Rate"]

# Estimated total annual cost in USD
df["Total_Annual_Cost_USD"] = (
    df["Tuition_USD_Adj"] / df["Duration_Years"] +
    df["Rent_USD_Adj"] * 12 +
    df["Visa_Fee_USD_Adj"] / df["Duration_Years"] +
    df["Insurance_USD_Adj"] / df["Duration_Years"]
)

# ----- Top 10 Most Expensive Countries -----
country_avg = df.groupby("Country")["Total_Annual_Cost_USD"].mean().sort_values(ascending=False)

plt.figure(figsize=(12, 6))
sns.barplot(x=country_avg.index[:10], y=country_avg.values[:10], palette="rocket")
plt.title("Top 10 Most Expensive Countries (Avg Annual Cost in USD)")
plt.ylabel("Avg Total Annual Cost (USD)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ----- Program Cost Distribution -----
plt.figure(figsize=(14, 6))
sns.boxplot(data=df, x="Program", y="Total_Annual_Cost_USD")
plt.title("Distribution of Annual Cost by Program")
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

# ----- Tuition vs Rent (All Cities) -----
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x="Tuition_USD_Adj", y="Rent_USD_Adj", hue="Country", alpha=0.6, s=60)
plt.title("Tuition vs Rent Across Countries (USD Adjusted)")
plt.xlabel("Tuition (USD)")
plt.ylabel("Rent (USD/month)")
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

# ----- Heatmap of Exchange Rates (Top Countries) -----
top_countries = df["Country"].value_counts().head(20).index
heat_df = df[df["Country"].isin(top_countries)].pivot_table(
    index="Country", columns="City", values="Exchange_Rate", aggfunc="mean"
)

plt.figure(figsize=(14, 8))
sns.heatmap(heat_df, annot=True, cmap="coolwarm", linewidths=0.5)
plt.title("Exchange Rate Heatmap (Top 20 Countries)")
plt.tight_layout()
plt.show()

